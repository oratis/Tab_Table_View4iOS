//
//  RandomViewController.h
//  TabTable
//
//  Created by Richard Archer on 4/14/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RandomViewController : UITableViewController

@property (strong, nonatomic) NSMutableArray *players;

@end
