//
//  Player.m
//  TabTable
//
//  Created by Richard Archer on 4/16/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "Player.h"

@implementation Player

@synthesize name;
@synthesize game;
@synthesize rating;

@end
