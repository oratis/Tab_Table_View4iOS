//
//  TabTableTests.m
//  TabTableTests
//
//  Created by Richard Archer on 4/14/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "TabTableTests.h"

@implementation TabTableTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    STFail(@"Unit tests are not implemented yet in TabTableTests");
}

@end
